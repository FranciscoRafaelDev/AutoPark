# AutoPark Dashboard (React)

Dashboard demonstrativo feito com React e Vite. Os números e registros ficam no objeto `sampleData` no início de `src/App.jsx` e podem ser alterados para testar outros cenários.

## Requisitos

- Node.js 20.19+ ou 22.12+
- Internet na primeira instalação das dependências

## Executar no computador

1. Extraia a pasta do ZIP.
2. Abra um terminal dentro de `autopark-react`.
3. Execute `npm install`.
4. Execute `npm run dev`.
5. Abra o endereço local mostrado no terminal.

Para criar a versão de produção, execute `npm run build`. Os arquivos prontos serão gerados em `dist/`.

## Login de demonstração

- Usuário: `admin`
- Senha: `autopark`

O login serve apenas para navegar no protótipo e não oferece autenticação real. O dashboard ainda não usa banco de dados nem sincroniza dados entre computadores.
