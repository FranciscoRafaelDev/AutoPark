import { useMemo, useState } from 'react';

const sampleData = {
  entriesToday: 28,
  exitsToday: 21,
  revenueToday: 487.5,
  vehicles: [
    { plate: 'ABC1D23', ticket: 'AP-001284', entry: '08:42', duration: '2h 18min', rate: 18.5 },
    { plate: 'FJK4A56', ticket: 'AP-001291', entry: '09:16', duration: '1h 44min', rate: 15 },
    { plate: 'GHT7B89', ticket: 'AP-001297', entry: '10:03', duration: '57min', rate: 12 },
    { plate: 'LMN2C34', ticket: 'AP-001302', entry: '10:27', duration: '33min', rate: 10 },
    { plate: 'PRS5D67', ticket: 'AP-001305', entry: '10:51', duration: '9min', rate: 8 },
  ],
  tickets: [
    { id: 'AP-001305', plate: 'PRS5D67', time: '10:51', type: 'Entrada', status: 'Emitido' },
    { id: 'AP-001302', plate: 'LMN2C34', time: '10:27', type: 'Entrada', status: 'Emitido' },
    { id: 'AP-001297', plate: 'GHT7B89', time: '10:03', type: 'Entrada', status: 'Emitido' },
    { id: 'AP-001291', plate: 'FJK4A56', time: '09:16', type: 'Entrada', status: 'Emitido' },
  ],
  payments: [
    { time: '10:34', ticket: 'AP-001276', plate: 'KLM8A12', method: 'Pix', amount: 25 },
    { time: '10:12', ticket: 'AP-001269', plate: 'BCD3E45', method: 'Cartão', amount: 18.5 },
    { time: '09:48', ticket: 'AP-001260', plate: 'EFG6H78', method: 'Dinheiro', amount: 12 },
    { time: '09:23', ticket: 'AP-001251', plate: 'IJK9L01', method: 'Pix', amount: 15 },
    { time: '08:55', ticket: 'AP-001243', plate: 'MNO2P34', method: 'Cartão', amount: 22 },
  ],
};

const currency = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });
const dateLabel = new Intl.DateTimeFormat('pt-BR', { dateStyle: 'full' }).format(new Date());
const pages = [
  ['overview', '▦', 'Visão geral'], ['vehicles', '🚗', 'Veículos'], ['tickets', '▤', 'Tickets'],
  ['payments', '＄', 'Pagamentos'], ['revenue', '▥', 'Faturamento'], ['charts', '▤', 'Gráficos'],
  ['reports', '◷', 'Relatórios'], ['settings', '⚙', 'Configurações'],
];
const pageTitles = Object.fromEntries(pages.map(([id, , label]) => [id, label]));

function Login({ onLogin }) {
  const [username, setUsername] = useState('admin');
  const [password, setPassword] = useState('autopark');
  const [error, setError] = useState('');
  function submit(event) {
    event.preventDefault();
    if (username.trim() === 'admin' && password === 'autopark') onLogin(username.trim());
    else setError('Usuário ou senha incorretos.');
  }
  return <section className="login-screen"><form className="login-card" onSubmit={submit}>
    <div className="login-brand"><div className="brand-mark">⌑</div><div className="brand-name">AutoPark</div><div className="brand-sub">Gestão de estacionamento</div></div>
    <h1>Acesse sua conta</h1><p className="muted">Entre para acompanhar a operação.</p>
    <label className="field">Usuário<input autoComplete="username" value={username} onChange={e => setUsername(e.target.value)} required /></label>
    <label className="field">Senha<input type="password" autoComplete="current-password" value={password} onChange={e => setPassword(e.target.value)} required /></label>
    <button className="primary">Entrar no painel</button><div className="login-error">{error}</div>
    <p className="demo-note">Acesso demonstrativo: admin / autopark</p>
  </form></section>;
}

function Card({ label, icon, value, hint }) {
  return <article className="card"><div className="card-top"><span>{label}</span><span className="card-icon">{icon}</span></div><div className="value">{value}</div><div className="hint">{hint}</div></article>;
}

function DataTable({ title, subtitle, headers, rows, searchable = true }) {
  const [query, setQuery] = useState('');
  const filteredRows = useMemo(() => rows.filter(row => row.join(' ').toLowerCase().includes(query.toLowerCase())), [rows, query]);
  return <section className="section"><div className="section-head"><div><h2 className="section-title">{title}</h2><div className="section-sub">{subtitle}</div></div>
    {searchable && <input className="search" placeholder="Buscar..." type="search" value={query} onChange={e => setQuery(e.target.value)} />}</div>
    <div className="table-wrap"><table><thead><tr>{headers.map(header => <th key={header}>{header}</th>)}</tr></thead><tbody>
      {filteredRows.length ? filteredRows.map((row, index) => <tr key={`${title}-${index}`}>{row.map((cell, cellIndex) => <td key={cellIndex}>{cell}</td>)}</tr>) : <tr><td className="empty" colSpan={headers.length}>Nenhum registro encontrado.</td></tr>}
    </tbody></table></div><div className="footer">{filteredRows.length} registro(s) · Valores de demonstração · {dateLabel}</div></section>;
}

function VehicleTable() {
  const rows = sampleData.vehicles.map(v => [<strong className="plate">{v.plate}</strong>, <span className="muted">{v.ticket}</span>, v.entry, v.duration, <span className="pill">Estacionado</span>]);
  return <DataTable title="Veículos estacionados" subtitle="Veículos atualmente no pátio" headers={['Placa', 'Ticket', 'Entrada', 'Tempo estacionado', 'Status']} rows={rows} />;
}

function RevenueChart() {
  const hours = [{ h: '07h', v: 32.5 }, { h: '08h', v: 74 }, { h: '09h', v: 98.5 }, { h: '10h', v: 126 }, { h: '11h', v: 81.5 }, { h: '12h', v: 38 }, { h: '13h', v: 37 }];
  const max = Math.max(...hours.map(item => item.v));
  return <section className="section"><div className="section-head"><div><h2 className="section-title">Quanto entrou por horário</h2><div className="section-sub">Valores recebidos em cada faixa do dia · dados ilustrativos</div></div></div>
    <div className="chart-area">{hours.map(item => <div className="bar-col" key={item.h}><div className="bar-track"><div className="bar revenue-bar" style={{ height: `${item.v / max * 100}%` }} title={currency.format(item.v)} /></div><span className="bar-label">{item.h}</span><span className="bar-value">{currency.format(item.v)}</span></div>)}</div>
    <div className="footer">O gráfico mostra o valor recebido em cada horário, não a quantidade de entradas de veículos.</div></section>;
}

function MovementChart() {
  const hours = [{ h: '07h', v: 3 }, { h: '08h', v: 8 }, { h: '09h', v: 12 }, { h: '10h', v: 16 }, { h: '11h', v: 10 }, { h: '12h', v: 7 }, { h: '13h', v: 11 }];
  return <section className="section"><div className="section-head"><div><h2 className="section-title">Movimento por horário</h2><div className="section-sub">Entradas de veículos ao longo do dia · dados ilustrativos</div></div></div>
    <div className="chart-area">{hours.map(item => <div className="bar-col" key={item.h}><div className="bar-track"><div className="bar" style={{ height: `${item.v / 16 * 100}%` }} /></div><span className="bar-label">{item.h}</span><span className="bar-value">{item.v} entradas</span></div>)}</div></section>;
}

function Summary() {
  const stats = [['Veículos no estacionamento', sampleData.vehicles.length], ['Entradas registradas', sampleData.entriesToday], ['Saídas registradas', sampleData.exitsToday], ['Faturamento confirmado', currency.format(sampleData.revenueToday)], ['Tickets de exemplo', sampleData.tickets.length], ['Pagamentos listados', sampleData.payments.length]];
  return <section className="section"><div className="section-head"><div><h2 className="section-title">Resumo do dia</h2><div className="section-sub">{dateLabel} · Indicadores de demonstração</div></div><button className="small-btn" onClick={() => window.print()}>Imprimir resumo</button></div><div className="report-grid">{stats.map(([label, value]) => <div className="report-item" key={label}><span>{label}</span><strong>{value}</strong></div>)}</div></section>;
}

function PageContent({ page }) {
  if (page === 'overview') return <><section className="cards"><Card label="Veículos estacionados" icon="🚘" value={sampleData.vehicles.length} hint="Veículos no pátio agora" /><Card label="Entradas de hoje" icon="↘" value={sampleData.entriesToday} hint="Registros de entrada hoje" /><Card label="Saídas de hoje" icon="↗" value={sampleData.exitsToday} hint="Registros de saída hoje" /><Card label="Faturamento do dia" icon="＄" value={currency.format(sampleData.revenueToday)} hint="Pagamentos confirmados hoje" /></section><div className="content"><VehicleTable /></div></>;
  if (page === 'vehicles') return <VehicleTable />;
  if (page === 'tickets') return <DataTable title="Tickets emitidos" subtitle="Últimos tickets gerados hoje" headers={['Número', 'Placa', 'Horário', 'Tipo', 'Status']} rows={sampleData.tickets.map(t => [<strong>{t.id}</strong>, t.plate, t.time, t.type, <span className="pill">{t.status}</span>])} />;
  if (page === 'payments') return <><section className="cards"><Card label="Faturamento de hoje" icon="＄" value={currency.format(sampleData.revenueToday)} hint="Pagamentos confirmados" /><Card label="Pagamentos" icon="✓" value={sampleData.payments.length} hint="Registros de exemplo" /></section><div className="content"><DataTable title="Pagamentos realizados" subtitle="Movimentações financeiras de hoje" headers={['Horário', 'Ticket', 'Placa', 'Método', 'Valor']} rows={sampleData.payments.map(p => [p.time, p.ticket, p.plate, p.method, currency.format(p.amount)])} /></div></>;
  if (page === 'revenue') return <><section className="cards"><Card label="Faturamento do dia" icon="＄" value={currency.format(sampleData.revenueToday)} hint="Total recebido hoje" /><Card label="Pagamentos listados" icon="✓" value={sampleData.payments.length} hint="Transações de exemplo" /><Card label="Ticket médio" icon="◉" value={currency.format(sampleData.revenueToday / sampleData.payments.length)} hint="Média por pagamento" /><Card label="Último recebimento" icon="◷" value="10:34" hint="Horário ilustrativo" /></section><div className="content"><RevenueChart /></div></>;
  if (page === 'charts') return <><MovementChart /><div className="content"><div className="report-grid"><div className="report-item"><span>Entradas</span><strong>{sampleData.entriesToday}</strong></div><div className="report-item"><span>Saídas</span><strong>{sampleData.exitsToday}</strong></div><div className="report-item"><span>Faturamento</span><strong>{currency.format(sampleData.revenueToday)}</strong></div></div></div></>;
  if (page === 'reports') return <Summary />;
  return <section className="section"><div className="section-head"><div><h2 className="section-title">Configurações básicas</h2><div className="section-sub">Preferências do protótipo</div></div></div><div className="report-grid"><label className="field">Nome do estacionamento<input className="control" defaultValue="AutoPark" /></label><label className="field">Nome de exibição<input className="control" defaultValue="Administrador" /></label><label className="field">Tema<select className="control" defaultValue="Escuro"><option>Escuro</option><option>Claro (em breve)</option></select></label><div className="report-item"><span>Usuário demonstrativo</span><strong>admin</strong></div><div className="report-item"><span>Senha demonstrativa</span><strong>autopark</strong></div><div className="report-item"><span>Modo de acesso</span><strong>Local / protótipo</strong></div></div><div className="footer">Login demonstrativo, sem autenticação segura ou integração com banco de dados.</div></section>;
}

export default function App() {
  const [user, setUser] = useState(() => sessionStorage.getItem('autopark-demo-login') || '');
  const [page, setPage] = useState('overview');
  function login(username) { sessionStorage.setItem('autopark-demo-login', username); setUser(username); }
  function logout() { sessionStorage.removeItem('autopark-demo-login'); setUser(''); }
  if (!user) return <Login onLogin={login} />;
  return <div className="layout"><aside className="sidebar"><div className="brand"><div className="brand-mark">⌑</div><div><div className="brand-name">AutoPark</div><div className="brand-sub">Gestão de estacionamento</div></div></div><div className="nav-label">MENU PRINCIPAL</div><nav className="nav">{pages.map(([id, icon, label]) => <button key={id} className={page === id ? 'active' : ''} onClick={() => setPage(id)}><span className="ico">{icon}</span>{label}</button>)}</nav><div className="side-bottom"><span className="status-dot" />Sistema operacional</div></aside>
    <main className="main"><header className="topbar"><div><div className="eyebrow">Painel de controle</div><h1 className="heading">{pageTitles[page]}</h1></div><div className="top-actions"><div className="date-chip">{dateLabel}</div><div className="avatar">{user[0].toUpperCase()}</div><button className="link-button" onClick={logout}>Sair</button></div></header><PageContent key={page} page={page} /></main></div>;
}
